================================================================================
                    EMAIL SPAM DETECTION SYSTEM
================================================================================

1. PROJECT OVERVIEW
--------------------------------------------------------------------------------
The Email Spam Detection System is an end-to-end Machine Learning and Natural
Language Processing (NLP) project designed to classify emails as either "Spam"
or "Ham (Normal)".

The project provides:
- A complete data exploration and model training pipeline in Jupyter Notebook.
- High-accuracy text classification using TF-IDF and Multinomial Naive Bayes.
- Pre-trained and serialized model artifacts for immediate inference.
- An interactive Command Line Interface (CLI) application.
- A modern desktop Graphical User Interface (GUI) built with Tkinter.


2. PROJECT DIRECTORY STRUCTURE
--------------------------------------------------------------------------------
Email Spam Detection/
│
├── dataset/
│   └── Enron_Txt_fn.csv          # Raw dataset (~33,716 emails, Enron corpus)
│
├── models/
│   ├── spam_model.pkl            # Trained Multinomial Naive Bayes model
│   └── tfidf_vectorizer.pkl      # Fitted TF-IDF Vectorizer (5,000 features)
│
├── notebooks/
│   └── spam_detection.ipynb      # EDA, preprocessing, model training & metrics
│
├── src/
│   ├── gui.py                    # Tkinter-based graphical desktop application
│   └── main.py                   # Terminal-based command-line interface
│
├── .vscode/
│   └── settings.json             # Workspace configuration
│
└── README.txt                    # Project documentation


3. DATASET INFORMATION
--------------------------------------------------------------------------------
- Source: Enron Email Corpus (dataset/Enron_Txt_fn.csv)
- Total Samples: 33,716 emails
- Features / Columns:
    * label    : Target class (0 = Ham, 1 = Spam)
    * email    : Raw text representation of the email
    * filename : Original file identifier
- Class Distribution:
    * Spam (1) : 17,171 emails (50.93%)
    * Ham (0)  : 16,545 emails (49.07%)
- Data Quality: 0 null/missing values, 0 duplicate records. Well-balanced dataset.


4. NLP & MACHINE LEARNING PIPELINE
--------------------------------------------------------------------------------
Data Preprocessing:
1. Syntax Parsing         : Handles string-encoded list formats using 
                            ast.literal_eval.
2. Case Normalization     : Converts all characters to lowercase.
3. Character Filtering    : Strips non-alphanumeric symbols and punctuation
                            using regex ([^a-zA-Z0-9\s]).
4. Whitespace Clean-up    : Collapses multiple spaces and trims outer edges.

Feature Extraction:
- Algorithm : Term Frequency-Inverse Document Frequency (TF-IDF)
- Features  : Top 5,000 vocabulary n-grams (max_features=5000)

Modeling:
- Classifier: Multinomial Naive Bayes (MultinomialNB)
- Split     : 80% Training (26,972 emails) / 20% Testing (6,744 emails)
- Strategy  : Stratified sampling (stratify=y, random_state=42)


5. MODEL PERFORMANCE & METRICS
--------------------------------------------------------------------------------
The trained MultinomialNB model achieves high performance on unseen test data:

- Test Accuracy : 98.07% (6,614 out of 6,744 correctly classified)

Detailed Classification Report:
                Precision    Recall    F1-Score    Support
  Ham (0)          0.99       0.97       0.98        3309
  Spam (1)         0.97       0.99       0.98        3435
  -------------------------------------------------------
  Accuracy                               0.98        6744
  Macro Avg        0.98       0.98       0.98        6744
  Weighted Avg     0.98       0.98       0.98        6744

Confusion Matrix (Test Set):
                      Predicted Ham    Predicted Spam
  Actual Ham (0)          3219               90
  Actual Spam (1)           40             3395


6. SYSTEM REQUIREMENTS & DEPENDENCIES
--------------------------------------------------------------------------------
Prerequisites:
- Python 3.8 or higher

Required Python Packages:
- pandas
- numpy
- scikit-learn
- nltk
- joblib
- matplotlib
- seaborn

To install dependencies, run:
    pip install pandas numpy scikit-learn nltk joblib matplotlib seaborn


7. HOW TO RUN THE APPLICATIONS
--------------------------------------------------------------------------------
1. Command Line Interface (CLI):
   Run the terminal application to evaluate emails interactively:
   
       python src/main.py
       
   - Enter email text at the prompt.
   - Shows predicted class (Spam or Ham) and confidence probability percentages.
   - Type 'exit' or 'quit' to exit.

2. Graphical User Interface (GUI):
   Launch the desktop interface:
   
       python src/gui.py
       
   - Paste or write email text into the input box.
   - Click "CLASSIFY EMAIL" to inspect results.
   - Displays clear color-coded alert badges (Spam alert / Ham confirmation).
   - Shows visual progress percentage bars for both Ham and Spam probabilities.
   - Use "LOAD EXAMPLES" to cycle through built-in test emails.
   - Use "CLEAR" to reset input and prediction cards.

3. Jupyter Notebook:
   To inspect or re-run the research and training pipeline:
   
       jupyter notebook notebooks/spam_detection.ipynb


8. SAVED ARTIFACTS
--------------------------------------------------------------------------------
The 'models/' directory stores pre-trained artifacts serialized using joblib:
- spam_model.pkl        : Serialized MultinomialNB classifier weights.
- tfidf_vectorizer.pkl  : Serialized TF-IDF vocabulary and IDF weights.

Both files are automatically loaded by 'src/main.py' and 'src/gui.py'.
================================================================================
